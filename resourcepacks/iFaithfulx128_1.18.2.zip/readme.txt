iFaithful x128 by Isaiah.
-------------------------

Credits:
	- Faithful x32 (faithful.team / faithfulpack.net)
	- tinypng.com
	- vectormagic.com
	- vpaint.app

